//Juan Carlos Velazco Rossell A01326707
//Carlos Parrodi Martinez A01421454
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.lang.Math;


class Point{
    int x,y;
    public Point(int a, int b){
        x=a;
        y=b;
    }
}

public class Main extends JPanel{
	
	public void paintComponent(Graphics g){
        super.paintComponent(g);
        Point a = new Point(400,0);
        Point b = new Point(750,606);
        Point c = new Point(50,606);
        int[] x = {a.x,b.x,c.x};
        int[] y = {a.y,b.y,c.y};
        int count = 5;
        int coloraug = 255/count;
        g.setColor(new Color(0+ coloraug*count,0,255-coloraug));
        g.fillPolygon(x, y, 3);
        sierpinski(a, b, c, count, g, coloraug);
        
    }
    
    public void sierpinski(Point a, Point b, Point c,int count,Graphics g,int coloraug){
        if(count==0)
            return;
  
        Point p1 = new Point(Math.round((a.x+c.x)/2),Math.round((a.y+c.y)/2));
        Point p2 = new Point(Math.round((b.x+c.x)/2),Math.round((b.y+c.y)/2));
        Point p3 = new Point(Math.round((a.x+b.x)/2),Math.round((a.y+b.y)/2));

        int[] halfX = {p1.x,p2.x,p3.x};
        int[] halfY = {p1.y,p2.y,p3.y};

        g.setColor(new Color(0+ coloraug*count,0,0 + coloraug*count));
        g.fillPolygon(halfX, halfY, 3);
   
        sierpinski(p1, c, p2, count-1, g, coloraug);
        sierpinski(a, p1, p3, count-1, g, coloraug);
        sierpinski(p3, p2, b, count-1, g, coloraug);

        return;

    }

	
	public static void main(String args[]){
		Main panel = new Main();
		JFrame application = new JFrame();
		application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		application.add(panel);
		application.setSize(800, 800);
		application.setVisible(true);
    }

}